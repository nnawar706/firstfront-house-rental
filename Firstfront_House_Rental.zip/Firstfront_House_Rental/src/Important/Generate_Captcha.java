/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Important;

import java.util.Random;

/**
 *
 * @author Nafisa
 */
public class Generate_Captcha {
    public static String generateCaptchaString(){
        Random rand = new Random();
        int length = 7 + (Math.abs(rand.nextInt()) % 3);
        StringBuffer captchaStringBuffer = new StringBuffer();
        for(int i=0;i<length;++i){
            int baseCharNumber = Math.abs(rand.nextInt()) % 62;
            int charNumber = 0;
            if(baseCharNumber < 26){
                charNumber = 65 + baseCharNumber;
            }
            else if(baseCharNumber < 52){
                charNumber = 97 + (baseCharNumber - 26);
            }
            else {
                charNumber = 48 + (baseCharNumber - 52);
            }
            captchaStringBuffer.append((char)charNumber);
        }
        return captchaStringBuffer.toString();
    }
    
    public static boolean Match_Captcha(String s1, String s2){
        if(s1.equals(s2)){
            return true;
        }
        return false;
    }
}
