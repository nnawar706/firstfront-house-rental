/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Important;

/**
 *
 * @author Nafisa
 */
public class Access_Data {
    public static int offerID;
    public static int userID;
    public static String Img_Path;
    public static int receiverID;
    public static String username;
    public static String message;
    
    public static void setOfferID(int id){
        offerID = id;
    }
    public static int getOfferID(){
        return offerID;
    }

    public static void setImgFilePath(String img_fileName) {
        Img_Path = img_fileName;
    }
    
    public static String getImgFilePath() {
        return Img_Path;
    }
    
    public static void setUserID(int id){
        userID = id;
    }
    
    public static int getUserID(){
        return userID;
    }

    public static void setReceiverID(int id) {
        receiverID = id;
    }
    
    public static int getReceiverID() {
        return receiverID;
    }

    public static void set_name(String name) {
        username = name;
    }
    
    public static String get_name(){
        return username;
    }

    public static void setMsg(String msg) {
        message = msg;
    }
    
    public static String getMsg(){
        return message;
    }
}
