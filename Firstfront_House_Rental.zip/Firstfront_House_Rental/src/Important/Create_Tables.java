/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Important;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Nafisa
 */
public class Create_Tables {
    public static void main(String[] args){
        Connection con = null;
        Statement st = null;
        try{
            con = Provide_Connection.getCon();
            st = con.createStatement();
            st.executeUpdate("create table users(name varchar(200), email varchar(100), national_ID int(20), contact int(15), password varchar(50), question varchar(200), answer varchar(200), status varchar(50), userID int NOT NULL AUTO_INCREMENT, PRIMARY KEY (userID));");
            st.executeUpdate("create table offers(offerID int NOT NULL AUTO_INCREMENT, name varchar(200), email varchar(100), contact varchar(15), flat_address varchar(500), sft int, description varchar(1000), price int, image varchar(200), uid int,status varchar(50), PRIMARY KEY (offerID));");
            st.executeUpdate("create table msgbox(msgID int NOT NULL AUTO_INCREMENT, senderID int, receiverID int,senderName varchar(50), msg varchar(500), PRIMARY KEY (msgID));");
            st.executeUpdate("create table wishlist(uid int, offerID int, address varchar(500), sft int, description varchar(1000), rent int);");
            st.executeUpdate("alter table users AUTO_INCREMENT=101;");
            st.executeUpdate("alter table offers AUTO_INCREMENT=101;");
            JOptionPane.showMessageDialog(null, "Table Created Successfully!");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
           try {
               con.close();
               st.close();
           } catch (Exception e){
               
           }
        }
    }
}
