/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Important;

import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Nafisa
 */
public class Manipulate_DB {
    public static void setData(String query, String msg){
        Connection con = null;
        Statement st = null;
        try{
            con = Provide_Connection.getCon();
            st = con.createStatement();
            st.executeUpdate(query);
            if(!msg.equals("")){
                JOptionPane.showMessageDialog(null, msg);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        finally{
            try{
                
            } catch(Exception e){
                
            }
        }
    }
}
