/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Important;

import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author Nafisa
 */
public class Generate_PDF {
    public void create_pdf(String name,String email, String contact, String address, String sft, String rent, String desc) {
        String path = "E:\\";
        com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
        try{
            PdfWriter.getInstance(doc, new FileOutputStream(path+""+Access_Data.getOfferID()+".pdf"));
            doc.open();
            Paragraph p1 = new Paragraph("FIRSTFRONT HOUSE RENTAL- A better way of living!");
            doc.add(p1);
            Paragraph p2 = new Paragraph("****************************************************************************************************************\n");
            doc.add(p2);
            
            Paragraph p3 = new Paragraph("**** OFFER INFORMATION - Offer ID-"+Access_Data.getOfferID()+" ****\n");
            doc.add(p3);
            Paragraph p4 = new Paragraph("****************************************************************************************************************\n");
            doc.add(p4);
            Paragraph p5 = new Paragraph("Name of The Owner: "+name+"\n");
            doc.add(p5);
            Paragraph p6 = new Paragraph("Email Address: "+email+"\n");
            doc.add(p6);
            Paragraph p7 = new Paragraph("Contact Number: "+contact+"\n");
            doc.add(p7);
            Paragraph p8 = new Paragraph("Address of the Apartment: "+address+"\n");
            doc.add(p8);
            Paragraph p9 = new Paragraph("Total Square Feet of Apartment: "+sft+"\n");
            doc.add(p9);
            Paragraph p10 = new Paragraph("Estimated Rent: "+rent+"\n");
            doc.add(p10);
            Paragraph p11 = new Paragraph("Description of the Apartment: "+desc+"\n");
            doc.add(p11);
            Paragraph p12 = new Paragraph("If you are interested to rent this house, please contact with the owner. Thank you");
            doc.add(p12);
            String file_path = Access_Data.getImgFilePath();
            Image img = Image.getInstance(file_path);
            doc.add(img);
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        doc.close();
        int a = JOptionPane.showConfirmDialog(null,"Do you want to download a copy?", "Select", JOptionPane.YES_NO_OPTION);
        if(a==0){
            try{
                if((new File("E:\\"+Access_Data.getOfferID()+".pdf")).exists()){
                    Process p = Runtime.getRuntime().exec("rundll32 url.dll, FileProtocolHandler E:\\"+Access_Data.getOfferID()+".pdf");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Caution: File does not exist.");
                }
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
}
